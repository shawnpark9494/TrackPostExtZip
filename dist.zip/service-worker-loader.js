import './assets/serviceworker.ts-ksIvIjJp.js';
