import './assets/serviceworker.ts-D-0U2gjq.js';
