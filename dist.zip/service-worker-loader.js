import './assets/serviceworker.ts-BFkspniB.js';
