import './assets/serviceworker.ts-CeuxGJwG.js';
