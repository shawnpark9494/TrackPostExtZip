import './assets/serviceworker.ts-BJoXhYuu.js';
