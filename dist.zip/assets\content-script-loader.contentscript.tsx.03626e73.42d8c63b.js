(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/contentscript.tsx.03626e73.js")
    );
  })().catch(console.error);

})();
