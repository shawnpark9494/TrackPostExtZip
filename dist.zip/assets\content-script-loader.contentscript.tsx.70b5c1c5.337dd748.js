(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/contentscript.tsx.70b5c1c5.js")
    );
  })().catch(console.error);

})();
