(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/contentscript.tsx.9769b846.js")
    );
  })().catch(console.error);

})();
