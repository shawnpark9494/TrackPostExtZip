(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/contentscript.tsx.46cbd459.js")
    );
  })().catch(console.error);

})();
