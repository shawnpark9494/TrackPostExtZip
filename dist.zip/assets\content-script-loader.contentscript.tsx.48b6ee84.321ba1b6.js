(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/contentscript.tsx.48b6ee84.js")
    );
  })().catch(console.error);

})();
